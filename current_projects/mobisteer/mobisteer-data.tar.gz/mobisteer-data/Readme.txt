---------------------------------------------------------
Stony Brook Mobisteer Data Logs 
9/28/2006-11-29-2006
http://www.wings.cs.sunysb.edu/wiki/doku.php?id=mobisteer
--------------------------------------------------------- 
This set of log files includes data traces that were collected from a
moving car equipped with electronically steerable Phocus Array Antenna
from Fidelity Comtech. We drove the car in two different environments in
Stony Brook University campus - Apartment Complex and Parking lot.  In the
apartment complex, we had setup up 5 Accesspoints (802.11g) alongside the
driving route. In the parking lot experiments, we only had one AP (802.11b)
covering the entire area. For both scenarios, the APs were configured to send
CBR traffic at 300 packets/second to the mobile node. Each file corresponds
to the data collected at the mobile node using kismet tool during one complete
drive along the route using one single beam pattern. We collected the data
for 9 beam patterns (given below) by driving 9 times along the same route,
each time with a different beam pattern. For the apartment complex scenario,
we have included the data collected on 12 different days.

Beam-0 - Omni

Directional beams (45deg beam width and 15dBi gain):
Beam-1 - 0deg
Beam-3 - 45deg
Beam-5 - 90deg
Beam-7 - 135deg
Beam-9 - 180deg
Beam-11 - 225deg
Beam-13 - 270deg
Beam-15 - 315deg

Data format is as follows:
    <gps-point ap=apt-ap1 time-sec=1163634436 time-usec=142102 lat=40.544773 lon=-73.066154 type=2 subtype=0 signal=10 noise=0 beamIndex=0 channel=6 datarate=110/>

Datarate field is interpreted as follows
10 -- 1.0 Mbps
20 -- 2.0 Mbps
50 -- 5.5 Mbps
110 -- 11.0 Mbps
60 -- 6.0 Mbps
120 -- 12.0 Mbps
180 -- 18.0 Mbps
360 -- 36.0 Mbps
90 -- 9.0 Mbps
240 -- 24.0 Mbps
480 -- 48.0 Mbps
540 -- 54.0 Mbps

If you use these traces in a research paper, please reference the traces as 

MobiSteer: Using Steerable Beam Directional Antenna for Vehicular Network Access
in Proceedings ACM MobiSys. June 2007

@InProceedings{Mobisteer-mobisys07,
  author = 	 {Vishnu Navda and Anand P. Subramanian and Kannan Dhanasekaran and Andreas Timm-Giel and Samir R. Das},
  title = 	 {{MobiSteer: Using Steerable Beam Directional Antenna for Vehicular Network Access}},
  booktitle = 	 {Proc. ACM Mobisys},
  year =	 2007,
  month =	 {June}
}
